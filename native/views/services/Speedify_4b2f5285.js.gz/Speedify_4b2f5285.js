const x = (e, s) => {
  const i = e.__vccOpts || e;
  for (const [d, t] of s)
    i[d] = t;
  return i;
}, U = {
  data() {
    return {
      snapshot: {},
      form: { enabled: !1, boot: !1, mode: "streaming", transport: "auto" },
      dirty: !1,
      loaded: !1,
      busy: !1,
      networkAck: !1,
      accountKind: "individual",
      logoutAck: !1,
      activationCode: "",
      activationUrl: "",
      priorities: {},
      linkRates: {},
      timer: null,
      previous: null,
      samples: [],
      rates: { download: "-", upload: "-" },
      updated: "-",
      accountOptions: [["individual", "Individual Speedify account"], ["router", "Router License account"]],
      modeOptions: [["streaming", "Streaming"], ["speed", "Speed"], ["redundant", "Redundant"]],
      transportOptions: [["auto", "Automatic"], ["udp", "UDP"], ["tcp", "TCP"], ["tcp-multi", "TCP multiple sockets"], ["https", "HTTPS"]],
      priorityOptions: [["automatic", "Automatic"], ["always", "Always"], ["secondary", "Secondary"], ["backup", "Backup"], ["never", "Never"]],
      columns: [{ dataIndex: "name", title: this.$t("Connection") }, { dataIndex: "device", title: this.$t("Interface") }, { dataIndex: "status", title: this.$t("Status") }, { dataIndex: "speedify", title: this.$t("Speedify adapter") }, { dataIndex: "rx", title: this.$t("Download") }, { dataIndex: "tx", title: this.$t("Upload") }, { dataIndex: "priority", title: this.$t("Priority") }]
    };
  },
  computed: {
    statusText() {
      var e;
      return this.snapshot.online ? (((e = this.snapshot.state) == null ? void 0 : e.state) || "Ready").replaceAll("_", " ") : this.$t("Stopped");
    },
    signedIn() {
      var e;
      return !!this.snapshot.online && !!((e = this.snapshot.state) != null && e.state) && this.snapshot.state.state !== "LOGGED_OUT";
    },
    accountText() {
      var e, s;
      return ((e = this.snapshot.user) == null ? void 0 : e.email) || (((s = this.snapshot.state) == null ? void 0 : s.state) === "LOGGED_OUT" ? this.$t("No Speedify account is signed in.") : this.$t("Start the service or refresh status to check your Speedify account."));
    },
    connections() {
      return (this.snapshot.links || []).map((e) => {
        var d, t, o, c;
        const s = (this.snapshot.modems || []).find((p) => p.name === e.name), i = (this.snapshot.adapters || []).find((p) => p.adapterID === e.device);
        return { ...e, name: (s == null ? void 0 : s.label) || (e.name === "wan" ? "Ethernet WAN" : e.name), status: e.up ? "Online" : (s == null ? void 0 : s.sim) || "Offline", adapter: i, speedify: i ? i.ispType || i.type || "Detected" : "Not detected", rx: ((t = (d = this.linkRates) == null ? void 0 : d[e.device]) == null ? void 0 : t.rx) || "-", tx: ((c = (o = this.linkRates) == null ? void 0 : o[e.device]) == null ? void 0 : c.tx) || "-" };
      });
    },
    rxPoints() {
      return this.points(0);
    },
    txPoints() {
      return this.points(1);
    }
  },
  mounted() {
    this.refresh(), this.timer = setInterval(() => {
      !this.busy && !document.hidden && this.refresh();
    }, 5e3);
  },
  beforeUnmount() {
    clearInterval(this.timer);
  },
  methods: {
    rate(e) {
      return e >= 1e6 ? (e / 1e6).toFixed(2) + " Mbps" : (e / 1e3).toFixed(1) + " kbps";
    },
    points(e) {
      const s = Math.max(1e5, ...this.samples.flat());
      return Array.from({ length: 60 }, (i, d) => {
        var o;
        const t = ((o = this.samples[d - (60 - this.samples.length)]) == null ? void 0 : o[e]) || 0;
        return `${d * 900 / 59},${95 - t / s * 90}`;
      }).join(" ");
    },
    async refresh() {
      var e, s;
      try {
        const { data: i } = await this.$axios.get("/api/speedify/status");
        this.snapshot = i, this.updated = (/* @__PURE__ */ new Date()).toLocaleTimeString(), (!this.loaded || !this.dirty) && (this.form = { enabled: i.online, boot: i.bootEnabled, mode: ((e = i.settings) == null ? void 0 : e.bondingMode) || "streaming", transport: ((s = i.settings) == null ? void 0 : s.transportMode) || "auto" }), this.loaded = !0, (i.adapters || []).forEach((o) => this.priorities[o.adapterID] = o.priority || "automatic"), this.linkRates = {};
        let d = 0, t = 0;
        if (this.previous && i.time > this.previous.time) {
          const o = i.time - this.previous.time;
          (i.links || []).forEach((c) => {
            var g;
            const p = (g = this.previous.links) == null ? void 0 : g.find((h) => h.device === c.device);
            if (p && c.device) {
              const h = Math.max(0, (c.rx - p.rx) * 8 / o), m = Math.max(0, (c.tx - p.tx) * 8 / o);
              d += h, t += m, this.linkRates[c.device] = { rx: this.rate(h), tx: this.rate(m) };
            }
          }), this.rates = { download: this.rate(d), upload: this.rate(t) }, this.samples.push([d, t]), this.samples = this.samples.slice(-60);
        }
        this.previous = i;
      } catch {
        this.$message.error(this.$t("Could not refresh Speedify status"));
      }
    },
    async command(e, s = {}) {
      const { data: i } = await this.$axios.post("/api/speedify/actions/execute", { data: { action: e, ...s } });
      return i;
    },
    async task(e) {
      var s, i, d, t;
      if (!this.busy) {
        this.busy = !0;
        try {
          await e(), await this.refresh(), this.$message.success(this.$t("Speedify settings applied"));
        } catch (o) {
          this.$message.error(((t = (d = (i = (s = o == null ? void 0 : o.response) == null ? void 0 : s.data) == null ? void 0 : i.errors) == null ? void 0 : d[0]) == null ? void 0 : t.error) || this.$t("Speedify action failed. Check activation and service status."));
        } finally {
          this.busy = !1;
        }
      }
    },
    execute(e) {
      return this.task(() => this.command(e));
    },
    async save() {
      return this.task(async () => {
        this.form.enabled && !this.snapshot.online && await this.command("start"), this.form.enabled && await this.command("preferences", { mode: this.form.mode, transport: this.form.transport }), !this.form.enabled && this.snapshot.online && await this.command("stop"), await this.command("boot", { enabled: !!this.form.boot }), this.dirty = !1;
      });
    },
    priority(e, s) {
      return this.task(() => this.command("priority", { id: e, value: s }));
    },
    connect() {
      return this.task(async () => {
        await this.command("connect", { acknowledge: this.networkAck }), this.networkAck = !1;
      });
    },
    clearActivation() {
      this.activationCode = "", this.activationUrl = "";
    },
    activate() {
      return this.task(async () => {
        this.clearActivation();
        const e = await this.command("signin", { account: this.accountKind });
        if (this.activationCode = (e == null ? void 0 : e.activationCode) || "", e != null && e.activationUrl) {
          const s = new URL(e.activationUrl);
          s.protocol === "https:" && s.hostname === "my.speedify.com" && (this.activationUrl = s.href);
        }
      });
    },
    signout() {
      return this.task(async () => {
        await this.command("signout", { acknowledge: this.logoutAck }), this.clearActivation(), this.logoutAck = !1, this.networkAck = !1;
      });
    }
  }
}, f = window.Vue.resolveComponent, a = window.Vue.createVNode, S = window.Vue.normalizeClass, u = window.Vue.withCtx, l = window.Vue.toDisplayString, y = window.Vue.createTextVNode, r = window.Vue.createElementVNode, b = window.Vue.openBlock, v = window.Vue.createElementBlock, k = window.Vue.createCommentVNode, _ = window.Vue.Fragment, N = window.Vue.createBlock, R = {
  class: "sfy-actions",
  style: { display: "flex", "align-items": "center", "flex-wrap": "wrap", gap: "16px" }
}, O = {
  class: "sfy-save",
  style: { display: "flex", "justify-content": "flex-end", padding: "24px" }
}, I = {
  class: "sfy-info",
  style: { padding: "8px 24px 24px", "line-height": "1.6" }
}, P = {
  class: "sfy-actions",
  style: { display: "flex", "align-items": "center", "flex-wrap": "wrap", gap: "16px" }
}, T = {
  href: "https://support.speedify.com/article/923-how-to-buy-a-router-license",
  target: "_blank",
  rel: "noopener noreferrer"
}, D = { key: 0 }, E = { key: 1 }, L = ["href"], B = { key: 2 }, M = { key: 1 }, G = {
  class: "sfy-info",
  style: { padding: "8px 24px 24px", "line-height": "1.6" }
}, F = ["aria-label"], K = ["points"], z = ["points"], H = { class: "sfy-muted" };
function W(e, s, i, d, t, o) {
  const c = f("tlt-form-item-switch"), p = f("tlt-dummy-value"), g = f("tlt-form-model-item"), h = f("tlt-form-item-select"), m = f("tlt-button"), C = f("tlt-form"), V = f("tlt-card"), A = f("tlt-table");
  return b(), v(_, null, [
    a(C, {
      ref: "speedifyForm",
      model: t.form,
      "custom-save": "",
      sid: "speedify",
      title: e.$t("Speedify")
    }, {
      default: u(() => [
        a(c, {
          modelValue: t.form.enabled,
          "onUpdate:modelValue": [
            s[0] || (s[0] = (n) => t.form.enabled = n),
            s[1] || (s[1] = (n) => t.dirty = !0)
          ],
          label: e.$t("Enable"),
          prop: "enabled"
        }, null, 8, ["modelValue", "label"]),
        a(g, {
          label: e.$t("Speedify status"),
          "element-id": "speedify-status"
        }, {
          default: u(() => {
            var n;
            return [
              a(p, {
                value: o.statusText,
                class: S(((n = t.snapshot.state) == null ? void 0 : n.state) === "CONNECTED" ? "success" : "text-theme-text-danger")
              }, null, 8, ["value", "class"])
            ];
          }),
          _: 1
        }, 8, ["label"]),
        a(c, {
          modelValue: t.form.boot,
          "onUpdate:modelValue": [
            s[2] || (s[2] = (n) => t.form.boot = n),
            s[3] || (s[3] = (n) => t.dirty = !0)
          ],
          label: e.$t("Start service on boot"),
          prop: "boot",
          help: e.$t("Starts the management service. VPN auto-connect stays off after a restart.")
        }, null, 8, ["modelValue", "label", "help"]),
        a(h, {
          modelValue: t.form.mode,
          "onUpdate:modelValue": [
            s[4] || (s[4] = (n) => t.form.mode = n),
            s[5] || (s[5] = (n) => t.dirty = !0)
          ],
          label: e.$t("Bonding mode"),
          prop: "mode",
          options: t.modeOptions,
          help: e.$t("Speed combines capacity. Streaming balances reliability and speed. Redundant duplicates packets and uses more data.")
        }, null, 8, ["modelValue", "label", "options", "help"]),
        a(h, {
          modelValue: t.form.transport,
          "onUpdate:modelValue": [
            s[6] || (s[6] = (n) => t.form.transport = n),
            s[7] || (s[7] = (n) => t.dirty = !0)
          ],
          label: e.$t("Transport protocol"),
          prop: "transport",
          options: t.transportOptions
        }, null, 8, ["modelValue", "label", "options"]),
        a(g, {
          label: e.$t("Default VPN route"),
          "element-id": "default-route"
        }, {
          default: u(() => {
            var n;
            return [
              a(p, {
                value: (n = t.snapshot.settings) != null && n.enableDefaultRoute ? e.$t("Enabled") : e.$t("Off")
              }, null, 8, ["value"])
            ];
          }),
          _: 1
        }, 8, ["label"]),
        a(g, {
          label: e.$t("VPN connection"),
          "element-id": "vpn-connection"
        }, {
          default: u(() => [
            r("div", R, [
              a(m, {
                disabled: t.busy || !t.snapshot.online || !t.networkAck,
                onClick: o.connect
              }, {
                default: u(() => [
                  y(l(e.$t("Connect")), 1)
                ]),
                _: 1
              }, 8, ["disabled", "onClick"]),
              a(m, {
                disabled: t.busy || !t.snapshot.online,
                onClick: s[8] || (s[8] = (n) => o.execute("disconnect"))
              }, {
                default: u(() => [
                  y(l(e.$t("Disconnect")), 1)
                ]),
                _: 1
              }, 8, ["disabled"])
            ])
          ]),
          _: 1
        }, 8, ["label"]),
        a(c, {
          modelValue: t.networkAck,
          "onUpdate:modelValue": s[9] || (s[9] = (n) => t.networkAck = n),
          label: e.$t("Prepare network for VPN"),
          prop: "networkAck",
          help: e.$t("Connect may create a Speedify interface and firewall zone, reload networking and enable the VPN default route. A valid Router License is required.")
        }, null, 8, ["modelValue", "label", "help"]),
        r("div", O, [
          a(m, {
            disabled: t.busy,
            onClick: o.save
          }, {
            default: u(() => [
              y(l(e.$t("Save & Apply")), 1)
            ]),
            _: 1
          }, 8, ["disabled", "onClick"])
        ])
      ]),
      _: 1
    }, 8, ["model", "title"]),
    a(V, {
      title: e.$t("Speedify account")
    }, {
      default: u(() => [
        r("div", I, [
          r("p", null, l(o.accountText), 1),
          r("p", null, l(e.$t("Sign in with your individual Speedify account or the account holding your Router License. Complete sign-in on the official Speedify website using email, Google, Apple or your available enterprise sign-in method.")), 1),
          r("p", null, l(e.$t("This device remains a router. An individual account must have a subscription that authorizes router use; this option does not convert a personal subscription into a Router License. Only one Speedify account can be active on this router at a time.")), 1),
          a(h, {
            modelValue: t.accountKind,
            "onUpdate:modelValue": [
              s[10] || (s[10] = (n) => t.accountKind = n),
              o.clearActivation
            ],
            label: e.$t("Sign-in option"),
            options: t.accountOptions
          }, null, 8, ["modelValue", "label", "options", "onUpdate:modelValue"]),
          r("div", P, [
            a(m, {
              disabled: t.busy || !t.snapshot.online || o.signedIn,
              onClick: o.activate
            }, {
              default: u(() => [
                y(l(t.accountKind === "individual" ? e.$t("Sign in to individual account") : e.$t("Activate Router License")), 1)
              ]),
              _: 1
            }, 8, ["disabled", "onClick"]),
            a(m, {
              type: "text",
              disabled: t.busy,
              onClick: o.refresh
            }, {
              default: u(() => [
                y(l(e.$t("Refresh status")), 1)
              ]),
              _: 1
            }, 8, ["disabled", "onClick"]),
            r("a", T, l(e.$t("Get a Router License")), 1)
          ]),
          t.activationCode ? (b(), v("p", D, [
            r("strong", null, l(e.$t("Activation code")) + ": " + l(t.activationCode), 1)
          ])) : k("", !0),
          t.activationUrl ? (b(), v("p", E, [
            r("a", {
              href: t.activationUrl,
              target: "_blank",
              rel: "noopener noreferrer"
            }, l(e.$t("Open Speedify sign-in")), 9, L)
          ])) : k("", !0),
          t.activationUrl ? (b(), v("p", B, l(e.$t("After signing in, return here and select Refresh status. Your Speedify password never passes through this UI.")), 1)) : k("", !0),
          o.signedIn ? (b(), v(_, { key: 3 }, [
            a(c, {
              modelValue: t.logoutAck,
              "onUpdate:modelValue": s[11] || (s[11] = (n) => t.logoutAck = n),
              label: e.$t("Confirm account sign-out"),
              help: e.$t("Signing out disconnects the VPN and clears the saved Speedify account session. Use this before switching accounts.")
            }, null, 8, ["modelValue", "label", "help"]),
            a(m, {
              disabled: t.busy || !t.logoutAck,
              onClick: o.signout
            }, {
              default: u(() => [
                y(l(e.$t("Sign out of Speedify")), 1)
              ]),
              _: 1
            }, 8, ["disabled", "onClick"])
          ], 64)) : k("", !0)
        ])
      ]),
      _: 1
    }, 8, ["title"]),
    a(A, {
      id: "speedify-connections",
      title: e.$t("Connections"),
      columns: t.columns,
      "data-source": o.connections,
      onRefresh: o.refresh
    }, {
      status: u(({ record: n }) => [
        a(p, {
          value: n.status,
          class: S(n.up ? "success" : "text-theme-text-danger")
        }, null, 8, ["value", "class"])
      ]),
      priority: u(({ record: n }) => [
        n.adapter ? (b(), N(h, {
          key: 0,
          modelValue: t.priorities[n.device],
          "onUpdate:modelValue": [(w) => t.priorities[n.device] = w, (w) => o.priority(n.device, w)],
          label: "",
          options: t.priorityOptions,
          disabled: t.busy
        }, null, 8, ["modelValue", "onUpdate:modelValue", "options", "disabled"])) : (b(), v("span", M, "-"))
      ]),
      _: 1
    }, 8, ["title", "columns", "data-source", "onRefresh"]),
    a(V, {
      title: e.$t("WAN activity")
    }, {
      default: u(() => [
        r("div", G, [
          r("p", null, l(e.$t("Physical WAN traffic, including traffic outside Speedify. These counters do not measure bonded VPN throughput.")), 1),
          r("p", null, [
            y(l(e.$t("Download")) + ": ", 1),
            r("strong", null, l(t.rates.download), 1),
            y(" | " + l(e.$t("Upload")) + ": ", 1),
            r("strong", null, l(t.rates.upload), 1)
          ]),
          (b(), v("svg", {
            class: "sfy-chart",
            width: "100%",
            height: "130",
            viewBox: "0 0 900 100",
            role: "img",
            "aria-label": e.$t("WAN download and upload history")
          }, [
            s[12] || (s[12] = r("path", {
              d: "M0 25H900M0 50H900M0 75H900",
              class: "sfy-grid",
              fill: "none",
              stroke: "currentColor",
              opacity: "0.12"
            }, null, -1)),
            r("polyline", {
              points: o.rxPoints,
              class: "sfy-rx",
              fill: "none",
              stroke: "#589cf3",
              "stroke-width": "2.5"
            }, null, 8, K),
            r("polyline", {
              points: o.txPoints,
              class: "sfy-tx",
              fill: "none",
              stroke: "#34b288",
              "stroke-width": "2.5"
            }, null, 8, z)
          ], 8, F)),
          r("p", H, l(e.$t("Last 5 minutes")) + " | " + l(e.$t("Updated")) + " " + l(t.updated), 1)
        ])
      ]),
      _: 1
    }, 8, ["title"])
  ], 64);
}
const $ = /* @__PURE__ */ x(U, [["render", W], ["__scopeId", "data-v-eb9b726d"]]);
export {
  $ as default
};
